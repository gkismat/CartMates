// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC8jXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
  authDomain: "fashionstore-collaborative.firebaseapp.com",
  projectId: "fashionstore-collaborative",
  storageBucket: "fashionstore-collaborative.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:xxxxxxxxxxxxxxxxxx"
};

// Initialize Firebase with error handling
let db, storage;
try {
  firebase.initializeApp(firebaseConfig);
  db = firebase.firestore();
  storage = firebase.storage();
  console.log('Firebase initialized successfully');
} catch (error) {
  console.warn('Firebase initialization failed, using localStorage only:', error);
  db = null;
  storage = null;
}

// Real-time reaction listener
class ReactionManager {
  constructor() {
    this.setupRealtimeListeners();
  }

  setupRealtimeListeners() {
    // Listen for new reactions (only if Firebase is available)
    if (db) {
      db.collection('reactions').onSnapshot((snapshot) => {
        snapshot.docChanges().forEach((change) => {
          if (change.type === 'added') {
            this.handleNewReaction(change.doc.data());
          }
        });
      });

      // Listen for AI suggestions
      db.collection('ai_suggestions').onSnapshot((snapshot) => {
        snapshot.docChanges().forEach((change) => {
          if (change.type === 'added') {
            this.handleNewSuggestion(change.doc.data());
          }
        });
      });
    } else {
      console.log('Firebase not available, using localStorage only');
    }
  }

  handleNewReaction(reaction) {
    console.log('New reaction received:', reaction);
    // Broadcast to cart page if needed
    this.broadcastToCart(reaction);
  }

  handleNewSuggestion(suggestion) {
    console.log('New AI suggestion:', suggestion);
    // Show suggestion popup if user is on cart page
    if (window.location.pathname.includes('cart.html')) {
      this.showSuggestionPopup(suggestion);
    }
  }

  broadcastToCart(reaction) {
    // Use localStorage for cross-page communication
    const cartReactions = JSON.parse(localStorage.getItem('collaborator_reactions') || '[]');
    cartReactions.push(reaction);
    localStorage.setItem('collaborator_reactions', JSON.stringify(cartReactions));
    
    // Also save with cart_reactions key for compatibility
    localStorage.setItem('cart_reactions', JSON.stringify(cartReactions));
    
    // Trigger storage event for real-time updates
    window.dispatchEvent(new StorageEvent('storage', {
      key: 'collaborator_reactions',
      newValue: JSON.stringify(cartReactions)
    }));
  }

  showSuggestionPopup(suggestion) {
    // Create suggestion popup
    const popup = document.createElement('div');
    popup.className = 'suggestion-popup';
    popup.innerHTML = `
      <div class="suggestion-content">
        <div class="suggestion-header">
          <h5>🤖 AI Recommendation</h5>
          <span class="confidence badge bg-${suggestion.suggestion.action === 'BUY' ? 'success' : 'warning'}">
            ${suggestion.suggestion.confidence} Confidence
          </span>
        </div>
        <div class="suggestion-body">
          <div class="action-recommendation ${suggestion.suggestion.action.toLowerCase()}">
            <i class="bi bi-${suggestion.suggestion.action === 'BUY' ? 'cart-check' : 'x-circle'}"></i>
            <span>${suggestion.suggestion.action}</span>
          </div>
          <p>${suggestion.suggestion.message}</p>
          <small class="text-muted">Based on collaborator feedback</small>
        </div>
        <div class="suggestion-actions">
          <button class="btn btn-sm btn-outline-secondary" onclick="this.closest('.suggestion-popup').remove()">
            Dismiss
          </button>
          <button class="btn btn-sm btn-primary" onclick="this.closest('.suggestion-popup').remove()">
            Thanks!
          </button>
        </div>
      </div>
    `;

    // Add styles
    popup.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.15);
      padding: 1.5rem;
      max-width: 350px;
      z-index: 9999;
      animation: slideIn 0.3s ease-out;
      border-left: 4px solid ${suggestion.suggestion.action === 'BUY' ? '#28a745' : '#ffc107'};
    `;

    document.body.appendChild(popup);

    // Auto-remove after 10 seconds
    setTimeout(() => {
      if (popup.parentNode) {
        popup.remove();
      }
    }, 10000);
  }
}

// Initialize reaction manager
const reactionManager = new ReactionManager();

// Utility functions for cart integration
window.CartIntegration = {
  addToCart: function(productId) {
    const cart = JSON.parse(localStorage.getItem('shopping_cart') || '[]');
    const existingItem = cart.find(item => item.productId === productId);
    
    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      cart.push({
        productId: productId,
        quantity: 1,
        addedAt: new Date().toISOString()
      });
    }
    
    localStorage.setItem('shopping_cart', JSON.stringify(cart));
    this.updateCartUI();
  },

  removeFromCart: function(productId) {
    let cart = JSON.parse(localStorage.getItem('shopping_cart') || '[]');
    cart = cart.filter(item => item.productId !== productId);
    localStorage.setItem('shopping_cart', JSON.stringify(cart));
    this.updateCartUI();
  },

  updateQuantity: function(productId, quantity) {
    const cart = JSON.parse(localStorage.getItem('shopping_cart') || '[]');
    const item = cart.find(item => item.productId === productId);
    
    if (item) {
      item.quantity = Math.max(1, quantity);
      localStorage.setItem('shopping_cart', JSON.stringify(cart));
      this.updateCartUI();
    }
  },

  updateCartUI: function() {
    // Update cart badge
    const cart = JSON.parse(localStorage.getItem('shopping_cart') || '[]');
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    
    document.querySelectorAll('.badge').forEach(badge => {
      if (badge.closest('.cart-dropdown') || badge.closest('[data-bs-toggle="dropdown"]')) {
        badge.textContent = totalItems;
      }
    });
    
    // Trigger cart update event
    window.dispatchEvent(new CustomEvent('cartUpdated', { detail: { cart, totalItems } }));
  }
};

// Add CSS for suggestion popup animation
const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn {
    from {
      transform: translateX(100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  .suggestion-popup .suggestion-content {
    background: white;
  }
  
  .suggestion-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
    padding-bottom: 0.5rem;
    border-bottom: 1px solid #eee;
  }
  
  .action-recommendation {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-weight: bold;
    font-size: 1.1rem;
    margin-bottom: 0.5rem;
  }
  
  .action-recommendation.buy {
    color: #28a745;
  }
  
  .action-recommendation.skip {
    color: #ffc107;
  }
  
  .suggestion-actions {
    display: flex;
    gap: 0.5rem;
    margin-top: 1rem;
    justify-content: flex-end;
  }
`;
document.head.appendChild(style);
